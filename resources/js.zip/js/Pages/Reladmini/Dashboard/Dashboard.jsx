import Navi from "../Components/Navi";

export default function Dashboard() {
    return (
        <>
            <Navi />
            "Dashboard... from component"
        </>
    );
}
